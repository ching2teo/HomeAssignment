﻿#include <Python.h>

using namespace std;

double generate(double min, double max)
{	
	return min + (double)rand() * (max - min) / (double)RAND_MAX;;
}

static PyObject* GetAccelerometerX(PyObject *self, PyObject *args)
{	
	return PyFloat_FromDouble(generate(-1, 1));
}
static PyObject* GetAccelerometerY(PyObject *self, PyObject *args)
{
	return PyFloat_FromDouble(generate(-1, 1));
}

static PyObject* GetAccelerometerZ(PyObject *self, PyObject *args)
{
	return PyFloat_FromDouble(generate(-1, 1));
}
static PyObject* GetGyroX(PyObject *self, PyObject *args)
{
	return PyFloat_FromDouble(generate(-180, 180));
}
static PyObject* GetGyroY(PyObject *self, PyObject *args)
{
	return PyFloat_FromDouble(generate(-10, 10));
}
static PyObject* GetGyroZ(PyObject *self, PyObject *args)
{
	return PyFloat_FromDouble(generate(-100, 100));
}


static PyMethodDef Methods[] = {	
	{ "GetAccelerometerX", GetAccelerometerX, METH_VARARGS, "something" },
	{ "GetAccelerometerY", GetAccelerometerY, METH_VARARGS, "something" },
	{ "GetAccelerometerZ", GetAccelerometerZ, METH_VARARGS, "something" },
	{ "GetGyroX", GetGyroX, METH_VARARGS, "something" },
	{ "GetGyroY", GetGyroY, METH_VARARGS, "something" },
	{ "GetGyroZ", GetGyroZ, METH_VARARGS, "something" },
	{ NULL, NULL }
};

static struct PyModuleDef ImuSensorData_module =
{
	PyModuleDef_HEAD_INIT,
	"ImuSensorData_module", /* name of module */
	"",/* module documentation, may be NULL */
	-1,/* size of per-interpreter state of the module, or -1 if the module keeps state in global variables. */
	Methods
};

PyMODINIT_FUNC PyInit_ImuSensorData(void) {
	return PyModule_Create(&ImuSensorData_module);

}
