#pragma once
#include <string>
using namespace std;
class ImuSensorData
{
private:
	double generate(double, double);
public:
	string getSensorData();
};