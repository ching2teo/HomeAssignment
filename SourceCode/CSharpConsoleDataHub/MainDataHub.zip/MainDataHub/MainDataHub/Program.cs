﻿using System;
using System.Text;
using System.Configuration;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;

namespace MainDataHub
{
    class Program
    {
        static void Main(string[] args)
        {
            MqttClient client;
            string clientId;
            string strMqttTopic = ConfigurationManager.AppSettings["BrokerTopic"];
            string BrokerAddress = ConfigurationManager.AppSettings["MqttBroker"];

            client = new MqttClient(BrokerAddress);
            // register a callback-function (we have to implement, see below) which is called by the library when a message was received
            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();
            try
            {
                client.Connect(clientId);
                Console.WriteLine("Broker "+ BrokerAddress + " connected");
                client.Subscribe(new string[] { strMqttTopic }, new byte[] { 2 });
                Console.WriteLine("Subscribe to " + strMqttTopic);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error:" + ex.Message);
            }
        }
        static void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            try
            {
                string strMessage = Encoding.UTF8.GetString(e.Message);
                //insert data to database
                Utility.clsDatabase.InsertRawData(strMessage);
                Console.WriteLine(strMessage);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error:" + ex.Message);
            }

        }
    }
}
