﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Configuration;
namespace MainDataHub.Utility
{
    public class clsDatabase
    {
        public static string CONSTRING = "Server="+ConfigurationManager.AppSettings["SQLServer"] +
                    "; Port="+ ConfigurationManager.AppSettings["SQLPort"] + 
                    "; Database="+ConfigurationManager.AppSettings["Database"]+
                    "; Uid="+ ConfigurationManager.AppSettings["Uid"] + 
                    "; Pwd="+ ConfigurationManager.AppSettings["Password"] + "; SslMode=Preferred;";
        public static int InsertTemperatureData(string sensorId, string timestamp, string temperature)
        {
            try
            {
                int Result = 0;
                string strCommand = String.Format("insert into temperaturesensor(sensor_id, temperature, reading_date, created_date) values('{0}', '{1}', '{2}', current_timestamp())"
                                    , sensorId, temperature, timestamp);
                Result = MySqlExecuteNonQuery(strCommand);

                return Result;
            }
            catch
            {
                
                return -1;
            }
        }

        public static int InsertGpsData(string sensorId, string timestamp, string longtitude, string latitude)
        {
            try
            {
                int Result = 0;
                string strCommand = String.Format("insert into gpssensor(sensor_id, longtitude, latitude, reading_date, created_date) values('{0}', '{1}', '{2}', '{3}', current_timestamp())"
                                    , sensorId, longtitude, latitude, timestamp);
                Result = MySqlExecuteNonQuery(strCommand);

                return Result;
            }
            catch
            {
                return -1;
            }
        }
        public static int InsertImuData(string sensorId, string timestamp, string accelerometer_x, string accelerometer_y, string accelerometer_z, string gyroscope_x, string gyroscope_y, string gyroscope_z)

        {
            try
            {
                int Result = 0;
                string strCommand = String.Format("insert into imusensor(created_date, sensor_id, reading_date, " +
                    "accelerometer_x, accelerometer_y, accelerometer_z, gyroscope_x, gyroscope_y, gyroscope_z) " +
                    "values(current_timestamp(), '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}')"
                                    , sensorId, timestamp, accelerometer_x, accelerometer_y, accelerometer_z, gyroscope_x, gyroscope_y, gyroscope_z);
                Result = MySqlExecuteNonQuery(strCommand);

                return Result;
            }
            catch 
            {
                return -1;
            }
        }
        public static int InsertRawData(string rawData)
        {
            try
            {
                int Result = 0;
                string strCommand = String.Format("insert into raw_data(created_date, raw_data) " +
                    "values(current_timestamp(), '{0}')", rawData);
                Result = MySqlExecuteNonQuery(strCommand);

                return Result;
            }
            catch 
            {
                return -1;
            }
        }
        private static int MySqlExecuteNonQuery(string strCommand)
        {
            try
            {
                int Result = 0;
                MySqlConnection conn = new MySqlConnection(CONSTRING);
                MySqlCommand cmd = new MySqlCommand(strCommand, conn);

                conn.Open();
                Result = cmd.ExecuteNonQuery();
                conn.Close();

                return Result;
            }
            catch(Exception ex)
            {
                return -1;
            }
        }
    }

   
}
